﻿using DFDS.TrackPlan.CalculateTruckDistance.Infrastructure;
using DFDS.TrackPlan.CalculateTruckDistance.Interface;
using DFDS.TrackPlan.CalculateTruckDistance.Service;
using SimpleInjector.Lifestyles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance
{
    public static class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var container = ContainerConfig.Setup();

                using (AsyncScopedLifestyle.BeginScope(container))
                {
                    DateTime endDate = DateTime.UtcNow;
                    var service = container.GetInstance<ITruckPlanService>();
                    service.CalculateAndStoreTruckPlanData(endDate);
                }
            }
            catch(Exception exp)
            {

            }
        }
    }
}
