﻿using DFDS.TrackPlan.CalculateTruckDistance.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Interface
{
    public interface IStorageRepository
    {
        IEnumerable<T> GetLastHourTruckPlans<T>(string tableName, DateTime startdate, DateTime enddate) where T : class;
        bool UpsertDataForLastHour(string tableName, CalculatedTruckPlans calculatedData);
        IEnumerable<T> GetMasterTruckPlanByPlanId<T>(string tableName, string planId) where T : class;

        double DistanceTravelledByMonth(string tableName, int age, DateTime monthYear, string Country);
        CalculatedTruckPlans DistanceDrivenForTruckPlan(string tableName,string PlanId);
    }
}
