﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Interface
{
    public interface ITruckPlanService
    {
        Task<bool> CalculateAndStoreTruckPlanData(DateTime endDate);
        
    }
}
