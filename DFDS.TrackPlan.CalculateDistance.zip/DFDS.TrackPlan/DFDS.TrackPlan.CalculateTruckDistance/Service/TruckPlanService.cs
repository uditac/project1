﻿using DFDS.TrackPlan.CalculateTruckDistance.Infrastructure;
using DFDS.TrackPlan.CalculateTruckDistance.Interface;
using DFDS.TrackPlan.CalculateTruckDistance.Model;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Service
{
    public class TruckPlanService : ITruckPlanService
    {
        private readonly Config _config;
        private readonly IStorageRepository _sqlRepository;
        public TruckPlanService(Config config, IStorageRepository sqlRepository)
        {
            _config = config;
            _sqlRepository = sqlRepository;
        }
        /// <summary>
        /// To Calculate the approximate distance travelled by a truck we are assuming that a Job Scheduler
        /// will run every hour which calculate the last hour data from the table RealTimePlan and for each PlanId we will upsert 
        /// the table CalculatedTruckPlan.
        /// At the end we will be Calculating the total distance,the drivers Age and Name,date of travel and the Country 
        /// travelled by a particular Truck
        /// </summary>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public async Task<bool> CalculateAndStoreTruckPlanData(DateTime endDate)
        {
            DateTime startDate = endDate.AddHours(-1);    //Calculate the last hour plan 
            var data = _sqlRepository.GetLastHourTruckPlans<RealTimePlan>(ApplicationContants.TableName_RealTimeTruckPlan, startDate, endDate);
            var planIds = (from r in data select r.PlanId).Distinct();
            foreach (string planid in planIds)
            {
                var truckPlans = (from plans in data orderby plans.DateValue where plans.PlanId == planid select plans);
                var totalDistanceForPlan = (from plans in truckPlans select plans.LastDistanceCovered).Sum();
                var lastHourDataForPlan = new CalculatedTruckPlans();
                lastHourDataForPlan.Distance = totalDistanceForPlan;
                //Get country from coordinates
                lastHourDataForPlan.Country = await GetCountryFromCoordinates(truckPlans.Select(lat => lat.Coordinate).FirstOrDefault()).ConfigureAwait(false);

                lastHourDataForPlan.TruckPlanId = planid;
                lastHourDataForPlan.StartDate = truckPlans.Select(d=>d.DateValue).FirstOrDefault();
                lastHourDataForPlan.EndDate = truckPlans.Select(d => d.DateValue).LastOrDefault();
                //Get driver information from master Truck Plans
                var masterPlan = _sqlRepository.GetMasterTruckPlanByPlanId<TablePlanMaster>(ApplicationContants.TableName_MasterTruckPlan, planid);

                lastHourDataForPlan.DriverName = masterPlan.FirstOrDefault().Driver;
                lastHourDataForPlan.DriverAge = masterPlan.FirstOrDefault().DriverAge;
                //Upsert calculated data to Calculated Truck Plans 
                var isSuccess = _sqlRepository.UpsertDataForLastHour(ApplicationContants.TableName_CalculatedTruckPlan, lastHourDataForPlan);
            }

            return true;
        }
        /// <summary>
        ///Ques 3. Find a way to get the country from a coordinate.
        /// </summary>
        /// <param name="coor"></param>
        /// <returns></returns>

        private async Task<string> GetCountryFromCoordinates(Coordinate coor)
        {
            using (var client = new HttpClient())
            {
                var baseAddress = new StringBuilder(_config.BingMapBaseUrl);
                var reqAddress = baseAddress.AppendFormat("{0},{1}?includeEntityTypes={2}&key{3}", coor.Longitude, coor.Lattitude, _config.APIParameter, _config.BingMapKey);
                //var httpRequestMessgae = new HttpRequestMessage(HttpMethod.Get, BaseAddress);
                var BaseAddress = new Uri("http://dev.virtualearth.net/REST/v1/Locations/47.64054,-122.12934?includeEntityTypes=CountryRegion&key=Al-XP5lpkHuhMOcclur7ScbRFpxY7m-mFzqx_jfPOEAXgiKzjO5YYVxod_FjW1fs");
                var result = client.GetAsync(BaseAddress).Result;
                string resultContent = await result.Content.ReadAsStringAsync().ConfigureAwait(false);
                var jsonLinq = JObject.Parse(resultContent);
                var srcArray = ((JArray)jsonLinq.Descendants().Where(d => d is JArray).First()).Descendants().Where(y => y is JArray).First().Children<JObject>().FirstOrDefault()
                    .Properties().ToList().Where(n => n.Name == "name").Select(m => m.Value).FirstOrDefault().Value<string>();
                return srcArray;
            }
        }
    }
}
