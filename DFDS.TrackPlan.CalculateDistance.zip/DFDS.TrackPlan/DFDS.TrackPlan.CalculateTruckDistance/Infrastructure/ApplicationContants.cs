﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Infrastructure
{
    public static class ApplicationContants
    {
        public static string TableName_RealTimeTruckPlan = "";
        public static string TableName_MasterTruckPlan = "";
        public static string TableName_CalculatedTruckPlan = "";

    }
}
