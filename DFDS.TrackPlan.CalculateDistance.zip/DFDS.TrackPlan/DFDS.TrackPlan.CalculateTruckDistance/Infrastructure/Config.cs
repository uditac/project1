﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Infrastructure
{
    public class Config
    {
        public string BingMapKey { get; set; }
        public string APIParameter { get; set; }

        public string BingMapBaseUrl { get; set; }
    }
}
