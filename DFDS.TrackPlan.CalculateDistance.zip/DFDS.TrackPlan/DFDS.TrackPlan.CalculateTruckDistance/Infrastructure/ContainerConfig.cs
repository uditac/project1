﻿using DFDS.TrackPlan.CalculateTruckDistance.Interface;
using DFDS.TrackPlan.CalculateTruckDistance.Repository;
using DFDS.TrackPlan.CalculateTruckDistance.Service;
using SimpleInjector;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Infrastructure
{
    public static class ContainerConfig
    {
        public static Container Setup()
        {
            var container = new Container();
            container.Register<Config>(() =>
            {
                return new Config()
                {
                    APIParameter = ConfigurationManager.AppSettings["APIParameter"],
                    BingMapKey = ConfigurationManager.AppSettings["BingMapKey"],
                    BingMapBaseUrl = ConfigurationManager.AppSettings["BingMapBaseUrl"]
                };
            }, Lifestyle.Singleton);

            container.Register<ITruckPlanService, TruckPlanService>();
            container.Register<IStorageRepository, SqlRepository>();

            return container;

        }
    }
}
