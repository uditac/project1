﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Model
{
    /// <summary>
    /// This class contains the Total Calculated Truck duration and distance.
    /// </summary>
   public class CalculatedTruckPlans
    {
        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public string TruckPlanId { get; set; }
        public int DriverAge { get; set; }
        public string DriverName { get; set; }
        public string Country { get; set; }
        public double Distance { get; set; }
    }
}
