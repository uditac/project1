﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Model
{
    /// <summary>
    /// To store Driver Information.
    /// </summary>
    public class TablePlanMaster
    {
        public string PlanId { get; set; }
        public string Driver { get; set; }

        public string DriverDOB { get; set; }

        public int DriverAge { get; set; }


    }
}
