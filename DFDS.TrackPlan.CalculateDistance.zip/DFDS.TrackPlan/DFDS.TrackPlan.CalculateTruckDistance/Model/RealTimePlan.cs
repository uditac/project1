﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Model
{
    /// <summary>
    /// This class will contain the real time value.
    /// </summary>
    public class RealTimePlan
    {
        public string PlanId { get; set; }
        public Coordinate Coordinate { get; set; }

        public double LastDistanceCovered { get; set; }

        public DateTime DateValue { get; set; }
    }
}
