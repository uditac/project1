﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Model
{
    /// <summary>
    /// The class will contain the coordinates of a truck plan.
    /// </summary>
    public class Coordinate
    {
        public string Lattitude { get; set; }
        public string Longitude { get; set; }
    }

}
