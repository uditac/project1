﻿using DFDS.TrackPlan.CalculateTruckDistance.Interface;
using DFDS.TrackPlan.CalculateTruckDistance.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TrackPlan.CalculateTruckDistance.Repository
{
    public class SqlRepository: IStorageRepository
    {
        /// <summary>
        /// Function to get the last hour details from RealTimePlan.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tableName"></param>
        /// <param name="startdate"></param>
        /// <param name="enddate"></param>
        /// <returns></returns>
        public IEnumerable<T> GetLastHourTruckPlans<T>(string tableName, DateTime startdate, DateTime enddate) where T : class
        {
            try
            {
                //
                return new List<T>();
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Upsert the last hour data to CalculatedTruckPlans Table.
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="calculatedData"></param>
        /// <returns></returns>
        public bool UpsertDataForLastHour(string tableName, CalculatedTruckPlans calculatedData)
        {
            try
            {
                return true;
            }
            catch(Exception exp)
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the driver Informatioin from TablePlanMaster.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="tableName"></param>
        /// <param name="planId"></param>
        /// <returns></returns>
        public IEnumerable<T> GetMasterTruckPlanByPlanId<T>(string tableName,string planId) where T : class
        {
            try
            {
                //
                return new List<T>();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Data Api to fetch total distance travelled by drivers with age more than the given.
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="age"></param>
        /// <param name="monthYear"></param>
        /// <param name="Country"></param>
        /// <returns></returns>
        public double DistanceTravelledByMonth(string tableName, int age, DateTime monthYear, string Country)
        {
            try
            {
                //
                var distance = 0.0;
                return distance;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Used to find out the approx distance driven by a given PlanId.
        /// </summary>
        /// <param name="tableName"></param>
        /// <param name="PlanId"></param>
        /// <returns></returns>
        public CalculatedTruckPlans DistanceDrivenForTruckPlan(string tableName, string PlanId)
        {
            try
            {
                //
                return new CalculatedTruckPlans();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
