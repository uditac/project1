﻿using DFDS.TrackPlan.CalculateTruckDistance.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DFDS.TruckPlans.DataApi.Interface
{
    /// <summary>
    /// 
    /// </summary>
    public interface ITruckPlanControllerService
    {
        /// <summary>
        /// Interface to implement total distance covered by a single truck plan.
        /// </summary>
        /// <param name="PlanId"></param>
        /// <returns></returns>
        CalculatedTruckPlans TruckPlanDistanceCovered(string PlanId);

        /// <summary>
        /// Interface to implement the total distance travelled by drivers with age more than the given.
        /// </summary>
        /// <param name="Age"></param>
        /// <param name="Country"></param>
        /// <param name="FilterMonth"></param>
        /// <returns></returns>
        double TruckPlanFilteredDistanceByDriver(int Age, string Country, DateTime FilterMonth);
    }
}
