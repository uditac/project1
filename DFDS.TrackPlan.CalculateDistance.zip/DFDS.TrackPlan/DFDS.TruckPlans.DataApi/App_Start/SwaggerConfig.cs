﻿using System.Web;
using System.Web.Http;
using DFDS.TruckPlans.DataApi.App_Start;
using Swashbuckle.Application;

[assembly: PreApplicationStartMethod(typeof(SwaggerConfig), "Register")]

namespace DFDS.TruckPlans.DataApi.App_Start
{
    public class SwaggerConfig
    {
        public static void Register()
        {
            GlobalConfiguration.Configuration
                .EnableSwagger(s =>
                {
                    s.SingleApiVersion("v1", "DFDS.TruckPlans.DataApi");
                })
            .EnableSwaggerUi(s =>
                {

                });
        }
    }
}