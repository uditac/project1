﻿using DFDS.TrackPlan.CalculateTruckDistance.Interface;
using DFDS.TrackPlan.CalculateTruckDistance.Repository;
using DFDS.TruckPlans.DataApi.Interface;
using DFDS.TruckPlans.DataApi.Service;
using SimpleInjector;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace DFDS.TruckPlans.DataApi.App_Start
{
    public class SimpleInjectorConfig
    {

        public static void Register(HttpConfiguration config)
        {
            var container = CreateContainer(new SimpleInjector.Lifestyles.AsyncScopedLifestyle());
        }

        public static Container CreateContainer(ScopedLifestyle defaultScope)
        {
            var container = new Container();
            container.Register<ITruckPlanControllerService, TruckPlanControllerService>();
            container.Register<IStorageRepository, SqlRepository>();

            return container;
        }
    }
}