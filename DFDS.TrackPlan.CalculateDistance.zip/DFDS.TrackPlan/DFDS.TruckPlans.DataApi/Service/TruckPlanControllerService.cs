﻿using DFDS.TrackPlan.CalculateTruckDistance.Interface;
using DFDS.TruckPlans.DataApi.Interface;
using DFDS.TrackPlan.CalculateTruckDistance.Infrastructure;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DFDS.TrackPlan.CalculateTruckDistance.Model;

namespace DFDS.TruckPlans.DataApi.Service
{
    public class TruckPlanControllerService : ITruckPlanControllerService
    {
        private readonly IStorageRepository _sqlRepository;
        public TruckPlanControllerService(IStorageRepository sqlRepository)
        {
            _sqlRepository = sqlRepository;
        }
        /// <summary>
        /// total distance covered for the given Plan id
        /// </summary>
        /// <param name="PlanId"></param>
        /// <returns></returns>
        public CalculatedTruckPlans TruckPlanDistanceCovered(string PlanId)
        {
            try
            {
                return _sqlRepository.DistanceDrivenForTruckPlan(ApplicationContants.TableName_CalculatedTruckPlan, PlanId);
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        ///  Total distance travelled by drivers with age more than the given.
        /// </summary>
        /// <param name="Age"></param>
        /// <param name="Country"></param>
        /// <param name="FilterMonth"></param>
        /// <returns></returns>
        public double TruckPlanFilteredDistanceByDriver(int Age, string Country, DateTime FilterMonth)
        {
            try
            {
                return _sqlRepository.DistanceTravelledByMonth(ApplicationContants.TableName_CalculatedTruckPlan, Age, FilterMonth, Country);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}