﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web.Http;
using DFDS.TrackPlan.CalculateTruckDistance.Infrastructure;
using DFDS.TrackPlan.CalculateTruckDistance.Interface;
using DFDS.TrackPlan.CalculateTruckDistance.Model;
using DFDS.TrackPlan.CalculateTruckDistance.Service;
using DFDS.TruckPlans.DataApi.Interface;

namespace DFDS.TruckPlans.DataApi.Controllers
{
   
    public class TruckPlanController : ApiController
    {
        private readonly ITruckPlanControllerService _truckPlanControllerService;
        public TruckPlanController(ITruckPlanControllerService truckPlanControllerService)
        {
            _truckPlanControllerService = truckPlanControllerService;
        }
        /// <summary>
        /// Data Api to fetch total distance travelled by drivers with age more than the given.
        /// </summary>
        /// <param name="age">Drivers Age</param>
        /// <param name="filterDate">Month & Year</param>
        /// <param name="Country">Truck Plan Country</param>
        /// <returns>Total distance covered</returns>
        [HttpGet]
        [Route("api/dfds/getdistancetravelledbydriverage")]
        public double DistanceTravelledByDrivers(int age,DateTime filterDate, string Country)
        {
            double result = _truckPlanControllerService.TruckPlanFilteredDistanceByDriver(age,Country,filterDate);
            return result;
        }

        /// <summary>
        /// Data api to get Truck Plan total distance covered for the given Plan id(Question 2)
        /// </summary>
        /// <param name="TruckPlanId">Truck Plan Id</param>
        /// <returns>Truck Plan Object</returns>
        [HttpGet]
        [Route("api/dfds/getdistancetravelledbytruckplan")]
        public IHttpActionResult ApproxDistanceDrivenByTruckPlan(string TruckPlanId)
        {
            var data = _truckPlanControllerService.TruckPlanDistanceCovered(TruckPlanId);
            return this.Ok(data);
        }
    }
}
